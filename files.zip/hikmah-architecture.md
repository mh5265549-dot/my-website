# Hikmah Business Platform — Architecture & Implementation Guide

---

## 1. System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER                             │
│  React.js (Next.js-compatible) + Tailwind CSS                   │
│  State: useState hooks + App-level state machine                │
│  Routing: Programmatic (no router dependency for prototype)      │
└──────────────────────┬──────────────────────────────────────────┘
                       │ HTTPS / REST API
┌──────────────────────▼──────────────────────────────────────────┐
│                        API LAYER                                │
│  Node.js + Express.js                                           │
│  Auth: JWT (jsonwebtoken) + bcrypt password hashing            │
│  File Uploads: multer (multipart/form-data)                     │
│  CORS: Configured per environment                               │
│  Middleware: authenticate(), requireAdmin()                     │
└──────────────────────┬──────────────────────────────────────────┘
                       │ Mongoose ODM
┌──────────────────────▼──────────────────────────────────────────┐
│                      DATABASE LAYER                             │
│  MongoDB                                                        │
│  Collections: users, branches, staff                            │
│  Indexes: email (unique), branchId (ref)                        │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Database Schema

### Collection: `users`
```js
{
  _id:                ObjectId,
  name:               String (required),
  email:              String (unique, lowercase),
  passwordHash:       String (bcrypt, 12 rounds),
  role:               Enum ["admin", "manager", "staff", "pending"],
  onboardingComplete: Boolean (default: false),
  createdAt:          Date,
  updatedAt:          Date
}
```
**Key Rule:** `userCount === 0` at registration time → `role = "admin"`. All subsequent users → `role = "pending"`.

### Collection: `branches`
```js
{
  _id:           ObjectId,
  name:          String (required),
  address:       String (required),
  contactNumber: String (required),
  createdBy:     ObjectId → ref users,
  isActive:      Boolean (default: true),
  createdAt:     Date
}
```

### Collection: `staff`
```js
{
  _id:              ObjectId,
  fullName:         String (required),
  profilePicture:   String (file path or null),
  phone:            String (required),
  emergencyContact: String (required, prominently labeled),
  branchId:         ObjectId → ref branches (required),
  isActive:         Boolean (default: true),
  createdBy:        ObjectId → ref users,
  createdAt:        Date
}
```

---

## 3. Authentication & Role Flow

```
User visits app
      │
      ▼
  JWT in localStorage?
      │
  YES ├──► Verify token expiry ──► Load /api/auth/me
      │         │
      │    INVALID ──► Redirect to Login
      │
  NO  └──► Auth Page (Login / Register)
                │
         REGISTER pressed
                │
         POST /api/auth/register
                │
         ┌──────▼──────────────┐
         │  userCount === 0?   │
         │  YES → role=admin   │
         │  NO  → role=pending │
         └──────┬──────────────┘
                │
          Store JWT token
                │
         ┌──────▼──────────────────────────────┐
         │  Is Admin?                          │
         │    onboardingComplete === false?     │
         │      branches.length === 0?          │
         │        → Onboarding Step 1 (Branch)  │
         │      branches.length > 0?            │
         │        → Onboarding Step 2 (Staff)   │
         │    onboardingComplete === true?      │
         │        → Dashboard                   │
         │  Is Pending?                         │
         │        → Pending Approval Page       │
         └──────────────────────────────────────┘
```

---

## 4. API Endpoints

| Method | Endpoint                        | Auth         | Description                        |
|--------|---------------------------------|--------------|------------------------------------|
| POST   | /api/auth/register              | Public       | Register; 1st user becomes Admin   |
| POST   | /api/auth/login                 | Public       | Login, returns JWT                 |
| GET    | /api/auth/me                    | JWT required | Get current user profile           |
| PATCH  | /api/auth/complete-onboarding   | Admin only   | Mark onboarding done               |
| GET    | /api/branches                   | JWT required | List all active branches           |
| POST   | /api/branches                   | Admin only   | Create a branch                    |
| GET    | /api/branches/:id               | JWT required | Get single branch                  |
| GET    | /api/staff                      | JWT required | List all staff (populated)         |
| POST   | /api/staff                      | Admin only   | Add staff (multipart w/ photo)     |
| GET    | /api/users                      | Admin only   | List all users (no passwords)      |
| PATCH  | /api/users/:id/role             | Admin only   | Update user role                   |

---

## 5. Frontend State Machine

```
App States:
  "loading"        → Check JWT, fetch /me
  "auth"           → Login / Register screen
  "onboard-branch" → Admin: Add first branch (REQUIRED)
  "onboard-staff"  → Admin: Add first staff member (REQUIRED)
  "pending"        → Non-admin waiting for approval
  "dashboard"      → Full dashboard (branches, staff, users tabs)

Transitions:
  login/register success    → determineState(user)
  onboard-branch complete   → "onboard-staff"
  onboard-staff complete    → API.completeOnboarding() → "dashboard"
  logout                    → clear JWT → "auth"
```

---

## 6. Project File Structure

```
hikmah/
├── client/                        # React frontend
│   ├── src/
│   │   ├── App.jsx                # Root state machine
│   │   ├── components/
│   │   │   ├── ui/                # Design system (Button, Input, Card...)
│   │   │   ├── auth/
│   │   │   │   └── AuthPage.jsx
│   │   │   ├── onboarding/
│   │   │   │   ├── AddBranchPage.jsx
│   │   │   │   └── AddStaffPage.jsx
│   │   │   └── dashboard/
│   │   │       ├── Dashboard.jsx
│   │   │       ├── BranchesTab.jsx
│   │   │       ├── StaffTab.jsx
│   │   │       └── UsersTab.jsx
│   │   ├── api/
│   │   │   └── client.js          # Axios instance w/ JWT interceptor
│   │   └── hooks/
│   │       └── useAuth.js
│   └── tailwind.config.js
│
├── server/                        # Node.js backend
│   ├── server.js                  # Entry point (this file)
│   ├── models/
│   │   ├── User.js
│   │   ├── Branch.js
│   │   └── Staff.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── branches.js
│   │   └── staff.js
│   ├── middleware/
│   │   └── auth.js                # authenticate, requireAdmin
│   └── uploads/
│       └── profiles/              # Profile picture storage
│
├── .env                           # MONGO_URI, JWT_SECRET, PORT
└── package.json
```

---

## 7. Environment Variables (.env)

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/hikmah
JWT_SECRET=your_very_strong_random_secret_here_256bits
CLIENT_URL=http://localhost:3000
NODE_ENV=development
```

---

## 8. Dependencies

### Backend (package.json)
```json
{
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "multer": "^1.4.5",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1"
  }
}
```

### Frontend
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.5.0"
  },
  "devDependencies": {
    "tailwindcss": "^3.3.3",
    "vite": "^4.4.9"
  }
}
```

---

## 9. Security Considerations

| Concern                  | Implementation                                         |
|--------------------------|--------------------------------------------------------|
| Password storage         | bcrypt with 12 salt rounds (never plaintext)           |
| Token security           | JWT signed with strong secret, 7-day expiry            |
| Password exposure        | `toJSON()` override strips `passwordHash` from output  |
| Admin bypass prevention  | Onboarding steps enforced at route level, not just UI  |
| File upload safety       | MIME type check, 5MB limit, unique filenames           |
| First-user admin logic   | `countDocuments()` check is atomic at DB query level   |
| CORS                     | Restricted to known CLIENT_URL in production           |
| Input validation         | Required field checks on every route                   |

---

## 10. Design System Tokens

```
Primary:    Deep Emerald  #065F46 (headers, nav, primary actions)
Accent:     Warm Gold     #D97706 (CTA buttons, highlights)
Surface:    White         #FFFFFF (cards, modals)
Background: Slate 50      #F8FAFC (page backgrounds)
Text:       Slate 800     #1E293B (headings)
Muted:      Slate 400     #94A3B8 (captions, placeholders)
Danger:     Red 600       #DC2626 (errors, warnings)
Emergency:  Gold 700      #B45309 (emergency contact highlight)
```
