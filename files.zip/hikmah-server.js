/**
 * ============================================================
 * HIKMAH BUSINESS PLATFORM — Backend Server
 * Node.js + Express + MongoDB (Mongoose)
 * ============================================================
 * Run: npm install && npm start
 * Requires: MongoDB running at MONGO_URI in .env
 */

require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "hikmah_jwt_secret_change_in_production";

// ============================================================
// MIDDLEWARE
// ============================================================
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:3000", credentials: true }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static("uploads"));

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = "uploads/profiles";
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `profile-${uniqueSuffix}${path.extname(file.originalname)}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true);
    else cb(new Error("Only image files are allowed"));
  },
});

// ============================================================
// DATABASE SCHEMAS (MongoDB / Mongoose)
// ============================================================

// --- User Schema ---
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: {
    type: String,
    enum: ["admin", "manager", "staff", "pending"],
    default: "pending",
  },
  onboardingComplete: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

UserSchema.pre("save", function (next) {
  this.updatedAt = new Date();
  next();
});

// Never expose password hash in API responses
UserSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  return obj;
};

const User = mongoose.model("User", UserSchema);

// --- Branch Schema ---
const BranchSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  address: { type: String, required: true, trim: true },
  contactNumber: { type: String, required: true, trim: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
});

const Branch = mongoose.model("Branch", BranchSchema);

// --- Staff Schema ---
const StaffSchema = new mongoose.Schema({
  fullName: { type: String, required: true, trim: true },
  profilePicture: { type: String, default: null }, // file path or URL
  phone: { type: String, required: true, trim: true },
  emergencyContact: { type: String, required: true, trim: true },
  branchId: { type: mongoose.Schema.Types.ObjectId, ref: "Branch", required: true },
  isActive: { type: Boolean, default: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  createdAt: { type: Date, default: Date.now },
});

const Staff = mongoose.model("Staff", StaffSchema);

// ============================================================
// AUTH MIDDLEWARE
// ============================================================
const authenticate = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token provided" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(payload.userId);
    if (!user) return res.status(401).json({ error: "User not found" });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
};

const requireAdmin = (req, res, next) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Admin access required" });
  next();
};

// ============================================================
// AUTH ROUTES  /api/auth
// ============================================================
const authRouter = express.Router();

// POST /api/auth/register
// ⚡ KEY LOGIC: First user ever = Admin
authRouter.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: "All fields required" });
    if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(400).json({ error: "Email already registered" });

    // First user in DB → Admin
    const userCount = await User.countDocuments();
    const role = userCount === 0 ? "admin" : "pending";

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, passwordHash, role });

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: "7d" });
    res.status(201).json({ user, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/login
authRouter.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error: "Invalid email or password" });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "Invalid email or password" });

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: "7d" });
    res.json({ user, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/auth/me
authRouter.get("/me", authenticate, (req, res) => res.json({ user: req.user }));

app.use("/api/auth", authRouter);

// ============================================================
// BRANCH ROUTES  /api/branches
// ============================================================
const branchRouter = express.Router();

// POST /api/branches — Create branch (Admin only)
branchRouter.post("/", authenticate, requireAdmin, async (req, res) => {
  try {
    const { name, address, contactNumber } = req.body;
    if (!name || !address || !contactNumber) return res.status(400).json({ error: "All fields required" });
    const branch = await Branch.create({ name, address, contactNumber, createdBy: req.user._id });
    res.status(201).json(branch);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/branches — List all branches
branchRouter.get("/", authenticate, async (req, res) => {
  const branches = await Branch.find({ isActive: true }).populate("createdBy", "name email");
  res.json(branches);
});

// GET /api/branches/:id — Single branch
branchRouter.get("/:id", authenticate, async (req, res) => {
  const branch = await Branch.findById(req.params.id);
  if (!branch) return res.status(404).json({ error: "Branch not found" });
  res.json(branch);
});

app.use("/api/branches", branchRouter);

// ============================================================
// STAFF ROUTES  /api/staff
// ============================================================
const staffRouter = express.Router();

// POST /api/staff — Add staff member
staffRouter.post("/", authenticate, requireAdmin, upload.single("profilePicture"), async (req, res) => {
  try {
    const { fullName, phone, emergencyContact, branchId } = req.body;
    if (!fullName || !phone || !emergencyContact || !branchId) {
      return res.status(400).json({ error: "All fields required" });
    }
    const branch = await Branch.findById(branchId);
    if (!branch) return res.status(400).json({ error: "Invalid branch" });

    const profilePicture = req.file ? `/uploads/profiles/${req.file.filename}` : null;
    const member = await Staff.create({ fullName, phone, emergencyContact, branchId, profilePicture, createdBy: req.user._id });
    res.status(201).json(await member.populate("branchId", "name address"));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/staff — List all staff (with branch info)
staffRouter.get("/", authenticate, async (req, res) => {
  const staff = await Staff.find({ isActive: true }).populate("branchId", "name address contactNumber");
  res.json(staff);
});

app.use("/api/staff", staffRouter);

// ============================================================
// ONBOARDING ROUTE
// ============================================================
app.patch("/api/auth/complete-onboarding", authenticate, requireAdmin, async (req, res) => {
  await User.findByIdAndUpdate(req.user._id, { onboardingComplete: true });
  res.json({ ok: true });
});

// ============================================================
// USERS ROUTE (Admin — manage user roles)
// ============================================================
app.get("/api/users", authenticate, requireAdmin, async (req, res) => {
  const users = await User.find().select("-passwordHash");
  res.json(users);
});

app.patch("/api/users/:id/role", authenticate, requireAdmin, async (req, res) => {
  const { role } = req.body;
  if (!["admin", "manager", "staff", "pending"].includes(role)) return res.status(400).json({ error: "Invalid role" });
  const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select("-passwordHash");
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json(user);
});

// ============================================================
// DB CONNECTION & SERVER START
// ============================================================
mongoose
  .connect(process.env.MONGO_URI || "mongodb://localhost:27017/hikmah", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(PORT, () => console.log(`🚀 Hikmah API running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error("❌ DB connection failed:", err.message);
    process.exit(1);
  });

module.exports = app;
